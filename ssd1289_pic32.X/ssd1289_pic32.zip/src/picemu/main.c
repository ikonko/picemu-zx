/* PICEMU - ZX Emulator System
 * Version 201303234_005
 */
#include <plib.h>           /* Include to use PIC32 peripheral libraries      */
#include <stdint.h>         /* For uint32_t definition                        */
#include <stdbool.h>        /* For true/false definition                      */
//#include <stdio.h>

#include "system.h"         /* System funct/params, like osc/periph config    */
#include "ssd1289.h"
#include "sim.h"
#include "simglb.h"
#include "sna.h"
#include "diskio.h"
#include "ff.h"
#include "ui.h"


unsigned int Ticks=0;           // Some ticks (don't know which timer)
unsigned int PFin=0;            // Keyboard input
unsigned char border=0;         // Border color
unsigned int bchange=0;         // Need to change border?
unsigned int brdrset=1;         // Border change setting effective
unsigned int flsh_state=0;      // State of flash counter
int ScrnRfsh = 1;               // Need to refresh the screen? - not used

UINT8   buf[1024];

// FatFS Timer settings
volatile BYTE rtcYear = 111, rtcMon = 11, rtcMday = 22;	// RTC starting values
volatile BYTE rtcHour = 0, rtcMin = 0, rtcSec = 0;
volatile unsigned long tick;	// Used for time benchmarking purposes
extern long Tstates;

FATFS Fatfs;

#define Tmax 69888              // Maximum T-states per video frame
//#define TLineMax 699

// DMA features
#define DmaTransferEvent  _TIMER_2_IRQ //this interrupt will start one DMA transfer 
#define PRESCALE_2            1 
#define TOGGLES_PER_SEC_2     800000 
#define T2_TICK               (80000000L/2/PRESCALE_2/TOGGLES_PER_SEC_2) 

// Let compile time pre-processor calculate the PR1 (period)
#define SYS_FREQ 		(80000000L)
#define PB_DIV         		2
#define PRESCALE       		256
#define TOGGLES_PER_SEC_I	50
#define T1_TICK       		(SYS_FREQ/PB_DIV/PRESCALE/TOGGLES_PER_SEC_I)

#define KMASK   0x3038


/*****************************************************************************
 * Function:  		void CoreTimerHandler(void)
 * PreCondition:
 * Input:           None
 * Output:          None
 * Side Effects:
 * Overview:        FatFs requires a 1ms tick timer to aid
 *					with low level function timing
 * Note:            Initial Microchip version adapted to work into ISR routine
 *****************************************************************************/
void __ISR(_CORE_TIMER_VECTOR, IPL2SOFT) CoreTimerHandler(void)
{
	static const BYTE dom[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	static int div1k;
	BYTE n;

	// clear the interrupt flag
	mCTClearIntFlag();
    // update the period
    UpdateCoreTimer(CORE_TICK_RATE);

	disk_timerproc();	// call the low level disk IO timer functions
	tick++;				// increment the benchmarking timer

	// implement a 'fake' RTCC
	if (++div1k >= 1000) {
		div1k = 0;
		if (++rtcSec >= 60) {
			rtcSec = 0;
			if (++rtcMin >= 60) {
				rtcMin = 0;
				if (++rtcHour >= 24) {
					rtcHour = 0;
					n = dom[rtcMon - 1];
					if ((n == 28) && !(rtcYear & 3)) n++;
					if (++rtcMday > n) {
						rtcMday = 1;
						if (++rtcMon > 12) {
							rtcMon = 1;
							rtcYear++;
						}
					}
				}
			}
		}
	}
}


/*********************************************************************
 * Function:  		DWORD get_fattime(void)
 * PreCondition:
 * Input:           None
 * Output:          Time
 * Side Effects:
 * Overview:        when writing fatfs requires a time stamp
 *					in this exmaple we are going to use a counter
 *					If the starter kit has the 32kHz crystal
 *					installed then the RTCC could be used instead
 * Note:
 ********************************************************************/
DWORD get_fattime(void)
{
	DWORD tmr;

	INTDisableInterrupts();
	tmr =	  (((DWORD)rtcYear - 80) << 25)
			| ((DWORD)rtcMon << 21)
			| ((DWORD)rtcMday << 16)
			| (WORD)(rtcHour << 11)
			| (WORD)(rtcMin << 5)
			| (WORD)(rtcSec >> 1);
	INTEnableInterrupts();

	return tmr;
}

// *****************************************************************************
// void UARTTxBuffer(char *buffer, UINT32 size)
// *****************************************************************************
void SendDataBuffer(const char *buffer, UINT32 size)
{
    while(size)
    {
        while(!UARTTransmitterIsReady(UART1))
            ;

        UARTSendDataByte(UART1, *buffer);

        buffer++;
        size--;
    }

    while(!UARTTransmissionHasCompleted(UART1))
        ;
}


// ZX Spectrum related routines
void LoadSNA(void) {
	unsigned int i;
	register unsigned u;
/*
 Offset   Size   Description
   ------------------------------------------------------------------------
   0        1      byte   I
   1        8      word   HL',DE',BC',AF'
   9        10     word   HL,DE,BC,IY,IX
   19       1      byte   Interrupt (bit 2 contains IFF2, 1=EI/0=DI)
   20       1      byte   R
   21       4      words  AF,SP
   25       1      byte   IntMode (0=IM0/1=IM1/2=IM2)
   26       1      byte   BorderColor (0..7, not used by Spectrum 1.7)
   27       49152  bytes  RAM dump 16384..65535
   ------------------------------------------------------------------------
   Total: 49179 bytes
*/

	I = SNA[0];
	L_ = SNA[1];
	H_ = SNA[2];
	E_ = SNA[3];
	D_ = SNA[4];
	C_ = SNA[5];
	B_ = SNA[6];
	F_ = SNA[7];
	A_ = SNA[8];
	L = SNA[9];
	H = SNA[10];
	E = SNA[11];
	D = SNA[12];
	C = SNA[13];
        B = SNA[14];

	IY = SNA[15] + 256*SNA[16];
	IX = SNA[17] + 256*SNA[18];

	IFF = (SNA[19] & 0x04) ? 3 : 0; 
	//(IFF & 2) ? (IFF |= 1) : (IFF &= ~1);

	R = SNA[20];

	F = SNA[21];
	A = SNA[22];

	STACK = ram + SNA[23] + 256*SNA[24];
	u = *STACK++;
	u += *STACK++ << 8;
	PC = ram + u;
	
	int_mode = SNA[25];

	border = SNA[26];
	
	for(i=0;i<49152;i++) {
		ram[16384+i] = SNA[27+i];	
	}
	
	// how to jump to code?

}

#define SNALEN 49152+27

void LoadSNA2(void) {
    unsigned char Buff;
    unsigned int i;
    register unsigned u;
    static unsigned int cnt=1;

         for(i=0;i<SNALEN;i++) {
            //rc = f_read (&file, &Buff, 1, &numread);
            Buff = SNA[i];
/*
            if (numread == 0) {
                zxprintf("RF!");
                break;
            }
*/
            if (i>26) {
                    ram[16384+(i-27)] = Buff;
            } else {

                if (i==0) I  = Buff;
                if (i==1) L_ = Buff;
                if (i==2) H_ = Buff;
                if (i==3) E_ = Buff;
                if (i==4) D_ = Buff;
                if (i==5) C_ = Buff;
	        if (i==6) B_ = Buff;
	        if (i==7) F_ = Buff;
	        if (i==8) A_ = Buff;
	        if (i==9) L = Buff;
	        if (i==10) H = Buff;
	        if (i==11) E = Buff;
	        if (i==12) D = Buff;
	        if (i==13) C = Buff;
                if (i==14) B = Buff;
                if (i==15) IY = Buff;
                if (i==16) IY += 256 * Buff;
                if (i==17) IX = Buff;
                if (i==18) IX += 256 * Buff;
                if (i==19) IFF = (Buff & 0x04) ? 3 : 0;

                if (i==20) R = Buff;

                if (i==21) F = Buff;
                if (i==22) A = Buff;

                if (i==23) STACK = ram + Buff;
                if (i==24) {
                    STACK += 256 * Buff;
                    u = *STACK++;
                    u += *STACK++ << 8;
                    PC = ram + u;
                }

                if (i==25) int_mode = Buff;

                if (i==26) border = Buff;

            }
        }
    zxprintf("L:%d\n",cnt);
    cnt++;
}

// Filesystem init
FRESULT FSInit(void) {
    
        FRESULT rc;
        DSTATUS ds;

        // +++ FatFS operations +++ //
        // Initialize Disk
        ds = disk_initialize(0);
        sprintf(buf,"Disk init status: %d\n",ds);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        // Mount Filesystem
        rc = f_mount(0, &Fatfs);
        sprintf(buf,"File system mount status: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        return(rc);
}

FRESULT FSUmount(void) {

    FRESULT rc;

   //unmount filesystem
    rc = f_mount(0,NULL);
    sprintf(buf,"File system umount status: %d\n",rc);
    SendDataBuffer(buf, strlen(buf));
    zxprintf(buf);

    return(rc);
}

// Scan dirs
FRESULT scan_files (
    char* path        /* Start node to be scanned (also used as work area) */
)
{
    FRESULT res;
    FILINFO fno;
    DIR dir;
    int i;
    char *fn;   /* This function is assuming non-Unicode cfg. */
/*
    #if _USE_LFN
    static char lfn[_MAX_LFN + 1];
    fno.lfname = lfn;
    fno.lfsize = sizeof lfn;
#endif
*/

    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) {
        i = strlen(path);
        for (;;) {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            if (fno.fname[0] == '.') continue;             /* Ignore dot entry */
//#if _USE_LFN
//            fn = *fno.lfname ? fno.lfname : fno.fname;
//#else
            fn = fno.fname;
//#endif
            if (fno.fattrib & AM_DIR) {                    /* It is a directory */
                sprintf(&path[i], "/%s", fn);
                res = scan_files(path);
                if (res != FR_OK) break;
                path[i] = 0;
            } else {                                       /* It is a file. */
                //zxprintf("%s/%s\n", path, fn);
                zxprintf("%20s",fn);
            }
        }
    }

    return res;
}

// Make filename global variable
char filename[13]; // 8\.3\0

unsigned char InputFileName_SNA() { // return number of characters
    //char filename[8];
    unsigned char k,x;
    unsigned long time;

    x=0;
    k = 0xFF;

    time = tick;
    while( tick < (time+500) );     // 500ms delay

    while(x<8) {
        /*do {
            k = InKey();
            if (k != 0xFF) break;
        } while (k == 0xFF);
        */

        while (k == 0xFF) {
            k = InKey();
        }

        if (k > ' ') zxprintf("%c",k);

        time = tick;
        while( tick < (time+200) );     // 200ms delay

        if (k=='\r') {
            filename[x] = '.';
            x++;
            filename[x] = 'S';
            x++;
            filename[x] = 'N';
            x++;
            filename[x] = 'A';
            x++;
            filename[x] = '\0'; // Null termination
            zxprintf("\n %s \n",filename);

            return (x);    // Enter = input done & return len of string
        }

        if ((k=='\x0C') && (x>0) ) {
            x--;    // Caps = Delete
            zxprintf("\b");    // Backspace
            continue;
        }
        //if ((k=='$') && (x>0) ) k = '.';   // Symbol = . (Dot)

        filename[x] = k;
        x++;
        k = 0xFF;

    }
}

unsigned char InputFileName_ROM() { // return number of characters
    //char filename[8];
    unsigned char k,x;
    unsigned long time;

    x=0;
    k = 0xFF;

    time = tick;
    while( tick < (time+500) );     // 500ms delay

    while(x<8) {
        /*do {
            k = InKey();
            if (k != 0xFF) break;
        } while (k == 0xFF);
        */

        while (k == 0xFF) {
            k = InKey();
        }

        if (k > ' ') zxprintf("%c",k);

        time = tick;
        while( tick < (time+200) );     // 200ms delay

        if (k=='\r') {
            filename[x] = '.';
            x++;
            filename[x] = 'R';
            x++;
            filename[x] = 'O';
            x++;
            filename[x] = 'M';
            x++;
            filename[x] = '\0'; // Null termination
            zxprintf("\n %s \n",filename);

            return (x);    // Enter = input done & return len of string
        }

        if ((k=='^') && (x>0) ) {
            x--;    // Caps = Delete
            zxprintf("\b");    // Backspace
            continue;
        }
        //if ((k=='$') && (x>0) ) k = '.';   // Symbol = . (Dot)

        filename[x] = k;
        x++;
        k = 0xFF;

    }
}

unsigned char InputFileName_TAP() {
    //char filename[8];
    unsigned char k,x;
    unsigned long time;

    x=0;
    k = 0xFF;

    time = tick;
    while( tick < (time+500) );     // 500ms delay

    while(x<8) {
        /*do {
            k = InKey();
            if (k != 0xFF) break;
        } while (k == 0xFF);
        */

        while (k == 0xFF) {
            k = InKey();
        }

        if (k > ' ') zxprintf("%c",k);

        time = tick;
        while( tick < (time+200) );     // 200ms delay

        if (k=='\r') {
            filename[x] = '.';
            x++;
            filename[x] = 'T';
            x++;
            filename[x] = 'A';
            x++;
            filename[x] = 'P';
            x++;
            filename[x] = '\0'; // Null termination
            zxprintf("\n %s \n",filename);

            return (x);    // Enter = input done & return len of string
        }

        if ((k=='^') && (x>0) ) {
            x--;    // Caps = Delete
            zxprintf("\b");    // Backspace
            continue;
        }
        //if ((k=='$') && (x>0) ) k = '.';   // Symbol = . (Dot)

        filename[x] = k;
        x++;
        k = 0xFF;

    }
}


//Save SNA to FAT
void SaveSNA_Fat(void) {
    long accessmode2;
    accessmode2= (FA_CREATE_ALWAYS | FA_OPEN_ALWAYS | FA_CREATE_NEW | FA_WRITE |FA_READ);

        FRESULT rc;
        DSTATUS ds;

        int i;
        DIR dir;
        char path[]="";
        char *fn;
        FILINFO fno;

        FIL file;
        unsigned char Buff,len;

        register unsigned u;
        unsigned int numwrtn=0;

        unsigned int PC_REAL;

        // Init & mount
        FSInit();

        // Directory listing
        rc = scan_files(path);
        sprintf(buf,"\nDir read code: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        len = InputFileName_SNA();


        rc = f_open(&file, filename, (BYTE)accessmode2);
        sprintf(buf,"OpenSNA: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        for(i=0;i<SNALEN;i++) {

            //rc = f_read (&file, &Buff, 1, &numread);

            if (i>26) {
                Buff = ram[16384+(i-27)];
            } else {
                if (i==0) Buff = I;
                if (i==1) Buff = L_;
                if (i==2) Buff = H_;
                if (i==3) Buff = E_;
                if (i==4) Buff = D_;
                if (i==5) Buff = C_;
	        if (i==6) Buff = B_;
	        if (i==7) Buff = F_;
	        if (i==8) Buff = A_;
	        if (i==9) Buff = L;
	        if (i==10) Buff = H;
	        if (i==11) Buff = E;
	        if (i==12) Buff = D;
	        if (i==13) Buff = C;
                if (i==14) Buff = B;
                if (i==15) Buff = (IY & 0x00FF);
                if (i==16) Buff = ((IY >>  8) & 0x00FF);
                if (i==17) Buff = (IX & 0x00FF);
                if (i==18) Buff = ((IX >>  8) & 0x00FF);
                if (i==19) Buff = (IFF == 3) ? 0x04 : 0x00 ;

                if (i==20) Buff = R;

                if (i==21) Buff = F;
                if (i==22) Buff = A;

//                if (i==23) Buff = ((STACK - ram) & 0x00FF);
//                if (i==24) Buff = (((STACK - ram) >> 8) & 0x00FF);
                if (i==23) { 
			// Push PC to stack
			PC_REAL = PC - ram;
			STACK--;
                        *STACK = ((PC_REAL >> 8) & 0x00FF);
			STACK--;
                        *STACK = (PC_REAL & 0x00FF);
			Buff = ((STACK - ram) & 0x00FF);
                }
                if (i==24) {
			Buff = (((STACK - ram) >> 8) & 0x00FF);
                        STACK++;
                        STACK++;
                }


                if (i==25) Buff = int_mode;

                if (i==26) Buff = border;

            }
            rc = f_write (&file, &Buff, 1, &numwrtn);

            if (numwrtn == 0) {
                zxprintf("Write Failed!\n");
                break;
            }

            
    }
    rc = f_close(&file);
    sprintf(buf,"File close status: %d\r\n",rc);
    SendDataBuffer(buf, strlen(buf));

    // Umount filesystem
    FSUmount();

    //return(0); // OK
}

#define ROMLEN 16384

void LoadROM_Fat() {
          long accessmode;
        //long accessmode2;

        accessmode= (FA_OPEN_EXISTING | FA_READ);

        FRESULT rc;
        DSTATUS ds;

        int i;
        DIR dir;
        char path[]="";
        char *fn;
        FILINFO fno;

        //char filename[] = "horski.sna";
        FIL file;
        unsigned char Buff,len;

        register unsigned u;
        unsigned int numread=0;
        unsigned char sure;
        //sprintf(str,"%4X",PORTA);
	//SSD1289_text(str,200,8,8,Green,Black);

        // Init & mount
        FSInit();

        // Directory listing
        rc = scan_files(path);
        sprintf(buf,"\nDir read code: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        len = InputFileName_ROM();

       for(sure=0;sure<2;sure++) {

        rc = f_open(&file, filename, (BYTE)accessmode);
        sprintf(buf,"OpenROM: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);
        for(i=0;i<ROMLEN;i++) {
             rc = f_read (&file, &Buff, 1, &numread);
            //Buff = SNA[i];

            if (numread == 0) {
                zxprintf("Read Failed!\n");
                break;
            }

            ram[i] = Buff;

        }
        rc = f_close(&file);
        sprintf(buf,"File close status: %d\r\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);
       } // sure

    // Umount filesystem
    FSUmount;

}


//Load SNA from FAT
void LoadSNA_Fat()
{
        long accessmode;
        //long accessmode2;
        
        accessmode= (FA_OPEN_EXISTING | FA_READ);

        FRESULT rc;
        DSTATUS ds;

        int i;
        DIR dir;
        char path[]="";
        char *fn;
        FILINFO fno;

        //char filename[] = "horski.sna";
        FIL file;
        unsigned char Buff,len;

        register unsigned u;
        unsigned int numread=0;
        unsigned char sure;
        //sprintf(str,"%4X",PORTA);
	//SSD1289_text(str,200,8,8,Green,Black);

        // Init & mount
        FSInit();

        // Directory listing
        rc = scan_files(path);
        sprintf(buf,"\nDir read code: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        len = InputFileName_SNA();

/*
 Offset   Size   Description
   ------------------------------------------------------------------------
   0        1      byte   I
   1        8      word   HL',DE',BC',AF'
   9        10     word   HL,DE,BC,IY,IX
   19       1      byte   Interrupt (bit 2 contains IFF2, 1=EI/0=DI)
   20       1      byte   R
   21       4      words  AF,SP
   25       1      byte   IntMode (0=IM0/1=IM1/2=IM2)
   26       1      byte   BorderColor (0..7, not used by Spectrum 1.7)
   27       49152  bytes  RAM dump 16384..65535
   ------------------------------------------------------------------------
   Total: 49179 bytes
*/
      for(sure=0;sure<2;sure++) {

        rc = f_open(&file, filename, (BYTE)accessmode);
        sprintf(buf,"OpenSNA: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        for(i=0;i<SNALEN;i++) {
            rc = f_read (&file, &Buff, 1, &numread);
            //Buff = SNA[i];

            if (numread == 0) {
                zxprintf("Read Failed!\n");
                break;
            }

            if (i>26) {
                    ram[16384+(i-27)] = Buff;
            } else {

                if (i==0) I  = Buff;
                if (i==1) L_ = Buff;
                if (i==2) H_ = Buff;
                if (i==3) E_ = Buff;
                if (i==4) D_ = Buff;
                if (i==5) C_ = Buff;
	        if (i==6) B_ = Buff;
	        if (i==7) F_ = Buff;
	        if (i==8) A_ = Buff;
	        if (i==9) L = Buff;
	        if (i==10) H = Buff;
	        if (i==11) E = Buff;
	        if (i==12) D = Buff;
	        if (i==13) C = Buff;
                if (i==14) B = Buff;
                if (i==15) IY = Buff;
                if (i==16) IY += 256 * Buff;
                if (i==17) IX = Buff;
                if (i==18) IX += 256 * Buff;
                if (i==19) IFF = (Buff & 0x04) ? 3 : 0;

                if (i==20) R = Buff;

                if (i==21) F = Buff;
                if (i==22) A = Buff;

                if (i==23) STACK = ram + Buff;
                if (i==24) {
                    STACK += 256 * Buff;
                    u = *STACK++;
                    u += *STACK++ << 8;
                    PC = ram + u;
                }

                if (i==25) int_mode = Buff;

                if (i==26) border = Buff;

            }
        } //next i (fill buffer)

        rc = f_close(&file);
        sprintf(buf,"File close status: %d\r\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);
      } //next sure

}

FIL tapefp;

// Open Tape file
unsigned int OpenTape() {   // Returns result: 0 = success, 1 = fail
        long accessmode;
        //long accessmode2;
        
        accessmode= (FA_OPEN_EXISTING | FA_READ);
        //FIL fp;

        FRESULT rc;
        DSTATUS ds;

        int i;
        DIR dir;
        char path[]="";
        char *fn;
        FILINFO fno;

        //char filename[] = "horski.sna";
        FIL file;
        unsigned char Buff,len;

        register unsigned u;
        unsigned int numread=0;
        unsigned char sure;
        //sprintf(str,"%4X",PORTA);
	//SSD1289_text(str,200,8,8,Green,Black);

        // Init & mount
        FSInit();

        // Directory listing
        rc = scan_files(path);
        sprintf(buf,"\nDir read code: %d\n",rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        len = InputFileName_TAP();

        rc = f_open(&tapefp, filename, (BYTE)accessmode);
        sprintf(buf,"TAP: %16s, %d\n", filename, rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        if (rc != FR_OK) {
                return(1); // file not found or couldn't be open
        }

        return(0);

}

// Standard ZX tape load
void Load_Trap () {
    int i,k;
    unsigned int base, lenght, dummy;
    //static FIL *fp = NULL;
//    extern FIL fp;
//    char fname[ 16], *np;
//    long accessmode;
    FRESULT rc;
    unsigned int numread=0;
    char x;
    static char gotname=1;

    if (strlen(filename) == 0) return;      // No file defined
//    accessmode = (FA_OPEN_EXISTING | FA_READ);

    // pre-load return address
    PC = ram + 0x806; // loading error
    // pre-load error
    //F |= C_FLAG;      // This is SCF!
    F &= ~C_FLAG;       //C_FLAG = 0 (flags.c = 0;)

    // get the block base address
    base = IX;
//    sprintf(buf,"Base: %d\n",base);
//    zxprintf(buf);
    
    // if looking for a header block (A=00)
    if (( A == 0) && ( gotname == 0 ))
        { // header
/*
            // mount an sd card, 10 quick tries
            for (i=0; i<10; i++)
            {
                rc = FSInit();
                if ( rc == FR_OK ) break; // if init succeeded, then skip next
            }
            if ( rc != FR_OK)
                return;     // card not found/initialized

            zxprintf("Zijem!\n");

            sprintf(buf,"Base: %d \n", base);
            SendDataBuffer(buf, strlen(buf));
            zxprintf(buf);

            for(i=0; i<8; i++) {

                x = ram[ base+1-17+i];
                if ( isalnum(x) ) {
                    fname[i] = toupper(x);
                    //np++;
                } else {
                    gotname=1;
                    break;
                }
            }

            fname[i] = '.';
            i++;
            fname[i] = 'T';
            i++;
            fname[i] = 'A';
            i++;
            fname[i] = 'P';
            i++;
            fname[i] = '\0';

            sprintf(buf,"Uz asi nezijem! %s \n",fname);
            zxprintf(buf);
            rc = f_open(&fp, fname, (BYTE)accessmode);
            sprintf(buf,"TAP: %16s, %d\n", fname, rc);
            SendDataBuffer(buf, strlen(buf));
            zxprintf(buf);


            if (rc != FR_OK) {
                return; // file not found or couldn't be open
            }
  */
        } // if looking for header

        lenght = 0;
        // read the TAP block lenght
        rc = f_read (&tapefp, &lenght, 2, &numread);

        sprintf(buf,"Block1: %d, %d, %d\n", lenght, numread, rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        // read the TAP block lenght
        //FSfread( &lenght, 1, 2, fp);

        dummy = 0;
        // read the block flag (first byte)
        rc = f_read (&tapefp, &dummy, 1, &numread);
        //FSfread( &dummy, 1, 1, fp);

        sprintf(buf,"Block1: %d, %d, %d\n", dummy, numread, rc);
        SendDataBuffer(buf, strlen(buf));
        zxprintf(buf);

        
        // check if the block type is a match
        if ( dummy == A)
        { // it can be loaded
            // compare the block (expected) lenght
            if ( lenght == ( (D<<8) + E + 2) )
            {
                // read a header/data block
                //FSfread( &ram[ base], 1, lenght-2, fp);
                rc = f_read(&tapefp, &ram[ base], lenght-2, &numread);
                // read the checksum (last byte)
                //FSfread( &dummy, 1, 1, fp);
                rc = f_read(&tapefp, &dummy, 1, &numread);
            }
            else    //  skip the (broken) block
            {
                //FSfseek( fp, lenght-1, 0);
                rc = f_lseek(&tapefp, lenght-1);
                return;         // return with error
            }
        } // if proper type

        // if TAP finished, close file
        if ( f_eof(&tapefp))
        {
            rc = f_close(&tapefp);
            //gotname=0;
            //fp = *NULL;
        }

        // return with success
        PC = ram + 0x053F; // SA/LD-RET
        F |= C_FLAG; //flags.c = 1;
//        break;
      
}

// Keyboard helper
void ShowKeyboardHelp() {
    DrawBorder(0);
    ZXPrint("0. Exit",0,231,0,7,0);
    scr2lcd();
}


#define ROWNUM1 0xFE
#define ROWNUM2 0xFE
/*
unsigned int ScanNumbers() {

    unsigned char row,col;
    unsigned int PortD,n=1;

//    unsigned char
    
    if (n==1) row = 0x08;     // A11 => 1..5
    if (n==2) row = 0x10;     // A12 => 6..0

    PortD = (row & 0x0F) | ((row & 0x30) << 4) | ((row & 0xC0) << 8);
    LATD = PortD;

    if ((PORTF & 0x3038) == 0x3038) {
        n++;
        if(n>2) n=1;

    } else {
        col = ((PORTF & 0x38) >> 3) | ((PORTF & 0x3000) >> 9) ;
        return ( 5*(n-1) + col );
    }
   
    return( 10 );
}
*/
// Menu
void Menu(void)
{
        unsigned int x;
	unsigned char col;
	unsigned char str[5];
        unsigned char k;        // Keyboard

        unsigned int x1,y1,dx,dy;
        unsigned int adr,dat,dum;
        //unsigned char dat;

	ZXPrint("PICEmu Menu",0,0,0,6,2);
	if ((PORTF & 0x3038) != 0x3038)
	{
		;
	} // Wait keyrelease

        //zxprintf("Hello Dolly!\n");

	PORTD = 0xFE;

	if ((PORTF & 0x3038) == 0x3038) {
		;
	} // Wait keypress

	//col = ((PORTF & 0x38) >> 3) | ((PORTF & 0x3000) >> 9) ;
	//sprintf(str,"%2x",col);
	//ZXPrint(str,0,7,0,7,0);
        ZXPrint("1. Keyboard help",0,8,0,0,7);
        ZXPrint("2. Save SNApshot",0,16,0,0,7);
        ZXPrint("3. Load SNApshot",0,24,0,0,7);
        ZXPrint("4. Load ROM & Reset",0,32,0,0,7);
        ZXPrint("5. Reset",0,40,0,0,7);
        ZXPrint("7. Open TAPe",0,48,0,0,7);
        ZXPrint("8. Poke",0,56,0,0,7);
        ZXPrint("9. Options",0,64,0,0,7);
        ZXPrint("0. Exit menu",0,72,0,0,7);

        while (1) {

            do {
                k = InKey();
                if (k != 0xFF) break;
            } while (k == 0xFF);

            //zxprintf("%c",k);

            if(k=='0') break;
            if(k=='1') ShowKeyboardHelp();
            if(k=='2') {
                SaveSNA_Fat();
                zxprintf("0. Exit");
            }
            if(k=='3') {
                    LoadSNA_Fat();
                    zxprintf("0. Exit");
                    //break;
            }

           if(k=='4') {
                    LoadROM_Fat();
                    // Disable interrupts
                    int_mode = 0;
                    IFF = 0;

                    wrk_ram = PC = STACK = ram;
                    break;
                    //zxprintf("0. Exit");
                    //break;
            }

            if(k=='5') {

                    // Disable interrupts
                    int_mode = 0;
                    IFF = 0;

                    // And reset
                    wrk_ram = PC = STACK = ram;
                    break;
            }

            if(k=='7') {
                OpenTape();
            }

            if(k=='8') {
                adr = InputNum("Enter address",16384,65535);
                dat = InputNum("Enter data",0,255);
                //dum = InputNum("Dummy",0,0);
                if ((adr > 16383) && (adr < 65536))  {
                    if (dat<256) ram[adr]= (BYTE) dat;
                }
                break;
            } // if

            if(k=='$') {
                HandleEvent();
            }

            if (k=='&') {
                y1 = InputNum("Yaxis",0,239);
                x1 = InputNum("Xaxis",0,319);
                dy = InputNum("Ydist",0,239-y1);
                dx = InputNum("Xdist",0,319-x1);
                SSD1289_box(y1,x1,dy,dx,Yellow);
            }
        } // while
    PFin = 0x3038;
}


// ---- ISR -----
// Z80 Interrupt generator
void __ISR(_TIMER_1_VECTOR, IPL2SOFT) Timer1Handler(void)
{
    static cntr=0;
    //static int line=0;
    // clear the interrupt flag
    mT1ClearIntFlag();

    //line++;
    //if (line==100) {
        int_type = INT_INT; // Perform ULA like interrupt by Timer1

        cntr++;             // Increment flash counter
    
            if (cntr == 16) {

                if (flsh_state==0) {
			flsh_state++;
		} else {
			flsh_state=0;
		}
		cntr=0;
            }
//        line = 0;
//    }

    if (Tstates > Tmax) {
            Tstates -= Tmax;        // Reset T states counter - used for timing
    } else {
        Tstates = 0;
    }
}  

//KBinput
unsigned char KBinput() {
    unsigned char n,r;
    unsigned char c[8];

    r=1;
    for(n=0;n<7;n++) {
        c[n] = readkbd(r);
        r <<= 1;
    }
    
}

// Main loop
int32_t main(void)
{

	unsigned int i=1;
	unsigned char txt[25];
    UINT8   buf[1024];

//#ifndef PIC32_STARTER_KIT
    /*The JTAG is on by default on POR.  A PIC32 Starter Kit uses the JTAG, but
    for other debug tool use, like ICD 3 and Real ICE, the JTAG should be off
    to free up the JTAG I/O */
    DDPCONbits.JTAGEN = 0;
//#endif

	//TRISG = 0x6FFF;     // RG 15 reset, RG12 beeper
        TRISG = 0x6CBF;       // RG 8 - SPI out, RG 7 - SPI in
                              // RG 6 - SPI clk(o), RG 9 - SPI CS(o)
	PORTG = 0x9FFF;

	TRISD = 0x0000;		// All out
//	TRISE = 0xFF00;		// RE0-RE7 => PMP0-PMP7

	TRISF = 0xFFFC;		// RF0-RF1 => PMP11-PMP10

        TRISA = 0xFFFB;         // RA2 => OUT, others => in

    // Enable optimal performance (from FatFS/NBIIFS ---***---)
    //INTEnableSystemMultiVectoredInt();
    SYSTEMConfigPerformance(GetSystemClock());
    mOSCSetPBDIV(OSC_PB_DIV_2);				// Use 1:1 CPU Core:Peripheral clocks
    OpenCoreTimer(CORE_TICK_RATE);			// Open 1 ms Timer
    // set up the core timer interrupt with a prioirty of 2 and zero sub-priority
    mConfigIntCoreTimer((CT_INT_ON | CT_INT_PRIOR_2 | CT_INT_SUB_PRIOR_0));
    // End config FatFS/NBIIFS ---***---

    /* TODO Add user clock/system configuration code if appropriate.  */
    //SYSTEMConfig( GetSystemClock() , SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);
	
    //mOSCSetPBDIV( OSC_PB_DIV_2 );	// Configure the PB bus to run at 1/2 the CPU frequency

     // Open core timer for delay function
    //OpenCoreTimer( 0xFFFFFFFF );

    //===============================================================================
    // Timer 2 init at 76800 hz gives 20 updates per sec for 128 x 240 pixel display = 3840 bytes to update
    OpenTimer2(T2_ON | T1_SOURCE_INT | T2_PS_1_1, T2_TICK);

   // STEP 2. configure Timer 1 using internal clock, 1:256 prescale
    OpenTimer1(T1_ON | T1_SOURCE_INT | T1_PS_1_256, T1_TICK);

    // set up the timer interrupt with a priority of 2
    ConfigIntTimer1(T1_INT_ON | T1_INT_PRIOR_2);

    //#ifdef DEBUG
    // Init UART1
    UARTConfigure(UART1, UART_ENABLE_PINS_TX_RX_ONLY);
    UARTSetFifoMode(UART1, UART_INTERRUPT_ON_TX_NOT_FULL | UART_INTERRUPT_ON_RX_NOT_EMPTY);
    UARTSetLineControl(UART1, UART_DATA_SIZE_8_BITS | UART_PARITY_NONE | UART_STOP_BITS_1);
    UARTSetDataRate(UART1, GetPeripheralClock(), 57600);
    UARTEnable(UART1, UART_ENABLE_FLAGS(UART_PERIPHERAL | UART_RX | UART_TX));

    sprintf(buf,"PIC32 ZX Emulator with FatFS support\r\n");
    SendDataBuffer(buf, strlen(buf));
    //#endif
    
    // enable multi-vector interrupts
    INTEnableSystemMultiVectoredInt();

    sprintf(buf,"Starting init sequence...\r\n");
    SendDataBuffer(buf, strlen(buf));

/* Z80 Interrupt test
	//Setup();
	while(1) {
		int_type=INT_INT; 
		cpu(); 
	}
*/
	//initialise PMP16
    SSD1289_PMP_init();
	
	//initialise LCD
    SSD1289_on();
    
	SSD1289_text("PIC32 ZX Spectrum Simulator",1,1,8,Yellow,Black);
        //SSD1289_testPixels();
	//scr2lcd();
	
	PFin = PORTF;
	sprintf(txt,"%4X",PFin);
	SSD1289_text(txt,160,312,8,Yellow,Black);

	Setup();
        cpu_state = RUNNING;

    while(1) {

//	   if ( ScrnRfsh == 1 ) {
//               ScrnRfsh = 0;
               Lscr2lcd(0,1);
//           } else {
//               Emulate();
//           }

           if ( (cpu_state == STOPPED) && (cpu_error != OPHALT ) )
           {
			sprintf(txt,"%4x",PC - ram);
        		ZXPrint(txt,0,0,0,6,2);

           }

	   if ((bchange == 1) && (brdrset == 1)) {
			DrawBorder(border);
			bchange = 0;
	   }

           // Show menu if "Space + M" is pressed
           if((PFin & KMASK) != KMASK) {

                        if ((PFin & KMASK) == 0x3010) Menu();

           }
    
    } //while
  
} //main

