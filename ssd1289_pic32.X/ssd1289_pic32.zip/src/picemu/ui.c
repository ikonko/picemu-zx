// This file contains User Interface functions
//
// Version: 20140105-01

#include <plib.h>           /* Include to use PIC32 peripheral libraries      */
#include "ssd1289.h"

// -----------------
// Keyboard routines
// -----------------

#define MAXROW 8
#define KEYROW1 LATDbits.LATD1
#define KEYROW2 LATDbits.LATD2
#define KEYROW3 LATDbits.LATD3
#define KEYROW4 LATDbits.LATD8
#define KEYROW5 LATDbits.LATD9
#define KEYROW6 LATDbits.LATD0
#define KEYROW7 LATDbits.LATD14
#define KEYROW8 LATDbits.LATD15
#define KEYROWS LATD
#define KEYINPS 0x3038
#define KEYMASK 0xFFFF
#define KEYCOLS PORTF

volatile unsigned long tick;	// Used for time benchmarking purposes
//#define BYTE unsinged char

unsigned char keys[] = {
' ',	// unused
'^','Z','X','C','V',    // A8       // Standard chars
'A','S','D','F','G',    // A9
'Q','W','E','R','T',    // A10
'1','2','3','4','5',    // A11
'0','9','8','7','6',    // A12
'P','O','I','U','Y',    // A13
'\r','L','K','J','H',   // A14
' ','$','M','N','B',    // A15

'^',':','$','?','/',    // A8       // Symbol shifted chars
'~','|','\\','{','}',    // A9
'<','%','>','<','>',    // A10
'!','@','#','$','%',    // A11
'_',')','(','\'','&',    // A12
'"',';','@','|','&',    // A13
'\r','=','+','-','^',   // A14
' ','$','.',',','*',    // A15


'^','z','x','c','v',    // A8       // Caps Shifted chars
'a','s','d','f','g',    // A9
'q','w','e','r','t',    // A10
'\x07','2','3','4','\x08',    // A11
'\x0C','9','\x09','\x0B','\x0A',    // A12
'p','o','i','u','y',    // A13
'\x0D','l','k','j','h',   // A14
' ','$','m','n','b',    // A15

};

/*
pause(long n) {
    asm("nop");

}
// Scan Shift Press
// Returns "Space" shift status in bit 7, Symbol in bit 6, Caps in bit 5
unsigned int GetShifts() {

    unsigned int k, y, x=0, row, v, symbol, caps, space;

    
        for(y=0;y<2;y++) {

            if (y==1) x=7;      // Just to columns has shifts
    
            x = 7;
            row = 0xFF - (1 << x);
            KEYROWS = (row & 0x0F) | ((row & 0x30) << 4) | ((row & 0xC0) << 8);
            //pause(100);

                k = KEYCOLS;		// Get raw column status
		if ( (k & KEYINPS) != KEYINPS) {

			v = 0xFF - ( ( ((k & 0x0038) >> 3) | ((k & 0x3000) >> 9) ) | 0x00E0 ); // Calculate bits in order
                        if ((v & 0x01) == 0x01) v = 0x01;
                        if ((v & 0x02) == 0x02) v = 0x02;
                        if ((v & 0x04) == 0x04) v = 0x03;
                        if ((v & 0x08) == 0x08) v = 0x04;
                        if ((v & 0x10) == 0x10) v = 0x05;
                }
//                if ( (x==7) && (v==1) ) space=1;
//                if ( (x==7) && (v==2) ) symbol=1;
//                if ( (x==0) && (v==1) ) caps=1;
//        }

                if (v==2) {
                    y=0x40;
                } else {
                    y=0;
                }

                return(y);
    //return( (0x80 && space) | (0x40 && symbol) | (0x20 && caps) );

}
*/

unsigned int GetZXKeys() {
    unsigned int i, k, caps=0, sym=0, p=0xFF, q=0, debug=0;
    unsigned char ch[10];
    WORD a=0xFEFF;
    BYTE c;

    debug = 0;

    for (i=0;i<8;i++) {

        c = readkbd(a);
        if ( (c & 0x1F) != 0x1F ) { // Key pressed

            c = ~c & 0x1F;  // Lower 5 bits are important when neg
            
            if (debug == 1) {
                sprintf(ch,"%4X",c);
                ZXPrint(ch,0,56,0,6,2);
            }

            // Exceptions for shifts
            if ( (i==0) &&  ((c&0x01) == 0x01) ) caps=1;
            if ( (i==7) &&  ((c&0x02) == 0x02) ) sym=1;
            
            // Store row # for calculatin in p
            if (p == 0xFF) p = i;   // Store in which row key is pressed
            if ( (caps == 1) && (i>0) ) p = i;  // Caps in row 0, get the key

            // Decode bits
            if ( ((c&0x01) == 0x01) && (i!=0) ) q = 1;
            if ( ((c&0x02) == 0x02) && (i!=7) ) q = 2;
            if ((c&0x04) == 0x04) q = 3;
            if ((c&0x08) == 0x08) q = 4;
            if ((c&0x10) == 0x10) q = 5;


            if (debug == 1) {
                sprintf(ch,"%4X",p);
                ZXPrint(ch,0,64,0,6,2);
            }
        }
        a <<= 1;
    }
    
    if (p != 0xFF)  {
        if ( (caps == 1) && (q == 0 ) ) return (0xFF);
        if ( (sym == 1)  && (q == 0 ) ) return (0xFF);
        k = 128*sym + 64*caps + 5 * p + q;
    } else {
        k = p;
    }

    if (debug == 1) {
        sprintf(ch,"%4X",k);
        ZXPrint(ch,0,70,0,6,2);
    }

    return(k);
}

/*

// Keyboard driver
unsigned int GetKeys() {

	unsigned int x,k,v,m;
        BYTE row;

        unsigned char ch[10];

	KEYROWS = KEYMASK;		// All rows inactive = log.1

        for(x=0;x<MAXROW;x++) {

            row = 0xFF - (1 << x);
            KEYROWS = (row & 0x0F) | ((row & 0x30) << 4) | ((row & 0xC0) << 8);
            //pause(100);

		k = KEYCOLS;		// Get raw column status
		if ( (k & KEYINPS) != KEYINPS) {

			v = 0xFF - ( ( ((k & 0x0038) >> 3) | ((k & 0x3000) >> 9) ) | 0x00E0 ); // Calculate bits in order
                        //v  = !m;

                        sprintf(ch,"%X",v);
                        ZXPrint(ch,0,56,0,6,2);
                        if ((v & 0x01) == 0x01) v = 0x01;
                        if ((v & 0x02) == 0x02) v = 0x02;
                        if ((v & 0x04) == 0x04) v = 0x03;
                        if ((v & 0x08) == 0x08) v = 0x04;
                        if ((v & 0x10) == 0x10) v = 0x05;
                        
                        // ( ( (x==0) && (v==1) )
                        if   ( (x==7) && (v==2) )  {
                            // Shifts are removed to separate function now
                        } else {
                            k = 5*x + v;
                            return(k);

                        }

                }

	}
	return(0xFF);		// Nothing pressed
}

*/
unsigned char InKey() {
    unsigned int k, p, s;
    unsigned long now;
    
    k = GetZXKeys();

    if(k != 0xFF) {
        p = k;

//        for (now=0;now<5000;now++) { asm("nop"); }
        // Debounce delay
        now = tick;
        while( tick < (now+80) );     // 80 ticks delay

        k = GetZXKeys();
        if (k != p) return(0xFF);              // Ghost signal

        p = k & 0x3F;                   // Mask the value
        if ( (k & 0x80) == 0x80) p+=40;     // Symbol
        if ( (k & 0x40) == 0x40) p+=80;     // Caps
        if ((p>0) && (p<121)) return(keys[p]);
    }
    return (0xFF);
}

// -----------------------------------------------------------------------------
// Keyboard can have 3 shifts: Symbol, Caps and "Space" Shift
// When key is pressed, we have to return shift status and code of key pressed
// -----------------------------------------------------------------------------

// String to integer conversion
unsigned int strToInt(char string[])
{
    int i, intValue, result = 0;
    for (i = 0; isdigit(string[i]); ++i)
    {
        intValue = string[i] - '0';
        result = 10 * result + intValue;
    }
    //zxprintf("%d",result);
    return result;
}


#define CHPL 40   // Char per line
#define UPBR 32   // Upper border

// Draw ugly box
void DrawBox(y1,x1,dy,dx) {
    unsigned int mx,my;
    //SSD1289_box(9*8+UPBR,8,(12-8)*8+UPBR,303,HYELLOW);

    SSD1289_box(y1,x1,dy,dx,HYELLOW);

    for(my=y1;my<=(y1+dy);my++)  {
        SSD1289_drawPixel(my,x1,Black);
        SSD1289_drawPixel(my,x1+dx,Black);
    }
    for(mx=x1;mx<=(x1+dx);mx++) {
        SSD1289_drawPixel(y1,mx,Black);
        SSD1289_drawPixel(y1+dy,mx,Black);
    }

}

// Get numeric input from keyboard
unsigned int InputNum(char *caption, int min,int max) {
    unsigned char ch[41];
    unsigned char k, c, m;
    unsigned char inp[11];
    unsigned int l, x, res;

    // Clear dialog area
    /*
    for (c=0;c<CHPL;c++) {
            ch[c]=' ';   // Clear string for printing
            if (c == (CHPL-1)) ch[c] = '\0';
    }
    for (c=9;c<13;c++) {
        ZXPrint(ch,0,UPBR+c*8,0,0,7);
    }
    */
    DrawBox(9*8+UPBR,8,(12-8)*8,303,HYELLOW);

    // Center caption
    l = strlen(caption);
    x = 8* ( (CHPL - l) / 2);
    sprintf(ch,"%s",caption);
    ZXPrint(ch,x,9*8+UPBR,0,7,0);

    sprintf(ch,"Input number [%d-%d]",min,max);
    l = strlen(ch);
    x = 8* ( (CHPL - l) / 2);
    ZXPrint(ch,x,10*8+UPBR,0,0,6);

    sprintf(ch,"%d",max);
    l = strlen(ch);
    m = l+1;                  // Max len of string
    x = 8* ( (CHPL - l) / 2);

    for (c=0;c<11;c++) inp[c]=' ';  // Clear output string

    c=0;    // Counter

    k = 0xFF;

    while ( (k != '\r') && (c<=m) ) {

        sprintf(ch," ");
        ZXPrint(ch,x+c*8,11*8+UPBR,0,6,0);      // Cursor


        k=InKey();

        if ( (k>='0') && (k<='9') ) {
            sprintf(ch,"%c",k);
            ZXPrint(ch,x+c*8,11*8+UPBR,0,0,6);
            inp[c] = k;
            c++;
        }

        if ( (k == 0x0C) && (c > 0) ) {    // Delete
            sprintf(ch," ");
            ZXPrint(ch,x+c*8,11*8+UPBR,0,0,6);
            c--;
        }

        if (k == 0x07) {    // Edit = start over
            //for (c=0;c<11;c++) inp[c]=' ';  // Clear output string
            strcpy(inp,"         \0");
            c=0;
            ZXPrint(inp,x+c*8,11*8+UPBR,0,0,6);
        }
    }

    res = (strToInt(inp));

    if ( (res<min) || (res>max) ) {
        sprintf(ch,"B Integer out of range, 0:1");
        l = strlen(ch);
        x = 8* ( (CHPL - l) / 2);
        ZXPrint(ch,x,12*8+UPBR,0,6,2);
        k = InKey();
    }
    return(res);
}

// Define name types
#define T_SNAP  1
#define T_ROM   2
#define T_TAP   3

// Input filename
unsigned char InputFileName(char *caption, unsigned int type) { // return number of characters
    extern char filename[];
    unsigned long time;
    char ch[41];
    char k, c, m;
    unsigned char inp[11];
    unsigned int l, x, res;
//    char *nch;

    time = tick;
    while( tick < (time+500) );     // 500ms delay

    // Clear dialog area
    for (c=0;c<CHPL;c++) {
            ch[c]=' ';   // Clear string for printing
            if (c == (CHPL-1)) ch[c] = '\0';
    }
    for (c=0;c<2;c++) {
        ZXPrint(ch,0,c*8,0,0,7);
    }
    //DrawBox(8,14,0,39);

    // Center caption
    l = strlen(caption);
    x = 8* ( (CHPL - l) / 2);
    sprintf(ch,"%s",caption);
    ZXPrint(ch,x,0,0,7,0);

    l = 12;
    m = l+1;                  // Max len of string
    x = 8* ( (CHPL - l) / 2);

    c=0;
    k = 0xFF;

    while ( (k != '\r') && (c<=m) ) {

        sprintf(ch," ");
        ZXPrint(ch,x+c*8,1*8,0,6,0);      // Cursor

        k=InKey();                        // Get the key
        
        if ( (k == 0x0C) && (c > 0) ) {    // Delete
            sprintf(ch," ");
            ZXPrint(ch,x+c*8,1*8,0,0,6);    // Print "backspace"
            filename[c] = '\0';             // Terminate the string here
            c--;
        }
        
        if (k == 0x07) {    // Edit = start over
            for (c=0;c<(strlen(filename)+1);c++) filename[c]=' ';  // Clear fname string
            c=0;
            ZXPrint(inp,x+c*8,1*8,0,0,6);
        }
        
        if ( (k > ' ') && (k <= 'z') ) {    // Printable ASCII char
            sprintf(ch,"%c",k);
            ZXPrint(ch,x+c*8,1*8,0,0,6);    // Print char
            filename[c] = k;                // Append it to filename
            c++;                            // And increment char counter
        }
        
    } 
    
    // If filename is less than 12 chars then add suffix
    if ( (k=='\r') && (c < m) ) {

            filename[c]='\0';
            if (type == T_SNAP) strcat(filename, ".SNA");
            if (type == T_TAP)  strcat(filename, ".TAP");
            if (type == T_ROM)  strcat(filename, ".ROM");
    }

return (strlen(filename));    // Enter = input done & return len of string

}