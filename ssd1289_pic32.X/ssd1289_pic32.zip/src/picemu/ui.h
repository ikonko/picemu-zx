/* 
 * File:   ui.h
 * Author: ikon
 *
 * Created on January 5, 2014, 11:12 AM
 */

#ifndef UI_H
#define	UI_H

#ifdef	__cplusplus
extern "C" {
#endif

unsigned char InKey();
unsigned int GetZXKeys();
//unsigned int GetShifts();

// -----------------------------------------------------------------------------


#ifdef	__cplusplus
}
#endif

#endif	/* UI_H */

